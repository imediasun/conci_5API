<?php 
$dbhost = 'localhost';
$dbport = '27017';
$databaseName = 'mongoappconciinfo1';
$dbUserName = 'monappconciinfousr1';
$dbPassword = 'uHappconciinfoV1';
?>