<?php 
define('APP_NAME','1490113053');
$config['encryption_key']='ETAzAHtHNTbj2C1J2JhWOAuubqlYFIDm';
$config['sess_cookie_name']=APP_NAME;
?>