<?php

/* 
 * Database and other configuration here
 */

define('database_name','gpappconciinfodb'); // MySQL Database Name
define('database_host','localhost'); // MySQL Host Name
define('database_user','appcofodbuser');	// MySQL user Name
define('database_password','sjreg093jtgasdf');	// MySQL Password

define('vhost','localhost');	// Xmpp Host/IP
define('vhost_name','app.conci.info');	// Xmpp Service Name
define('vhost_admin_name','admin');	// Xmpp Admin User Name (without service name)
define('vhost_admin_password','6dfghe25rerg5');	// Xmpp Admin Password
